/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileTransmitter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import static java.lang.Integer.min;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author uesr
 */
public class clientReaderWriter implements Runnable{
    public ConnectionUtillities connection;
    public String userName ;
    public clientReaderWriter(String username, ConnectionUtillities con){
        connection=con;
        userName = username ;
    }
    
    @Override
    public void run() {
        
        Scanner in=new Scanner(System.in);
        Object o ;
        String data ;
        //System.out.println("clientreader starts..........");
        o = connection.read() ;
        data = o.toString();
        if(data.matches("login Failed"))
        {
            System.err.println("login is denied by server! BYE!BYE!!");
            return ;
        }
        while(true){
            
            System.out.println("For Sending file , write 'send'" );
            System.out.println("For Logging out, write 'logout'" );
            System.out.println("For Recieving file, write 'receive'" );
            String text ;
            text = "nothning" ;
            
            text = in.nextLine(); 
            if(text.matches("logout"))
            {
                System.out.println("student "+userName+" goes to offline now!");
                connection.write(text);
                o = connection.read() ;
                data = o.toString() ;
                if(data.matches("logout")){break ;}
                else { System.err.println("jhamela :/ :/");}
                //System.out.println("login "+ Client.login );
                //break ;
            }
            if( text.matches("send"))
            {
                System.out.println("write the student id of the receiver");
                text = in.nextLine() ;
                connection.write("studentID:"+text);
                o = connection.read() ;
                data = o.toString() ;
                //System.err.println("Server response : "+ data );
                if(data.matches("receiver not Found"))
                {
                    System.err.println("receiver not Found");
                    System.out.println("please type 'OK' to continue");
                }
                else if(data.matches("receiver Found! plz send filename and filesize"))
                {
                    System.out.println("receiver Found");
                    System.out.println("please write the filename.");
                }
                text = in.nextLine() ;
                if(text.matches("OK")){continue ;}
                String fileName = text ;
                File file = new File(fileName);
                long fileSize =  file.length() ;
                //System.out.println("filesize is "+ fileSize );
                connection.write("fileName&Size:"+fileName+":"+fileSize);
                //System.out.println("filenamesize pathylam");
                o = connection.read() ;
                data = o.toString() ;
                //System.out.println("server response : "+ data);
                if(data.matches("Sorry. due to overflow, file transmission can not be allowed"))
                {
                    System.err.println("Sorry. due to overflow, file transmission can not be allowed");
                    continue ;
                }
                else
                {
                   int maxChunkSIze = Integer.parseInt(data) ;
                   //System.out.println("maxChunkSIze is "+ maxChunkSIze);
                   o = connection.read() ;
                   data = o.toString() ;
                   //System.out.println("file ID is "+ data);
                   int fileID = Integer.parseInt(data) ;
                   byte[] bytesArray = new byte[(int) file.length()];
                   FileInputStream fis;
                    try {
                        fis = new FileInputStream(file);
                        fis.read(bytesArray); //read file into bytes[]
                        fis.close();
                        Chunk chunk ;
                        int last = 0 ;
                        long maxGap = 30000000000L ;
                        while(true)
                        {
                            if(last==fileSize){
                                connection.write("complete");
                                break ;
                            }
                            else
                            {
                                connection.write("will send more chunk");
                            }
                            byte [] newByteArray;
                            int chunkSize = (min(maxChunkSIze, (int) (fileSize-last))) ;
                            newByteArray = new byte[chunkSize];
                            for(int i = 0 ; i < chunkSize ; i ++ )
                            {
                                newByteArray[i] = bytesArray[last+i] ;
                            }
                            last += chunkSize ;
                            chunk = new Chunk(fileID,newByteArray);
                            long startTime = System.nanoTime();
                            connection.write(chunk);
                            String msg = (String) connection.read();
                            long timeGap = System.nanoTime() - startTime ;
                            if(timeGap > maxGap )
                            {
                                connection.write("TIMEOUT");
                                break;
                            }
                            if(msg.matches("got")){continue;}
                            else 
                            {
                                System.err.println("winter is coming");
                            }
                        }
                        data = (String) connection.read() ;
                        System.out.println(data);
                        
                        //while(true);
                        //Chunk chunk = new Chunk(fileID,bytesArray) ;
                        //System.out.println("chunk is :  ");
                        //chunk.print();
                        //connection.write(chunk) ;
                    } catch (FileNotFoundException ex) {
                        //Logger.getLogger(clientReaderWriter.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                       // Logger.getLogger(clientReaderWriter.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                   
                }
            }
            else if(text.contains("receive"))
            {
                System.out.println("You are in now receiver mode!");
                data = (String) connection.read() ;
                //System.out.println("new file is coming "+data) ;
                String msg[]=data.split(":",4);
                
                System.out.println("Student "+msg[0]+ " send a file named "+msg[1] + " of size "+msg[2]+" bytes");
                System.out.println("Do you want to download it ?");
                text = in.nextLine() ;
                //System.out.println("client response "+ text);
                
                String fileName = msg[1] ;
                if(text.matches("yes"))
                {
                    connection.write(text+",I want to receive file") ;
                    connection.write(data);
                    //System.out.println("file rcv korte chai..........s");
                    byte bytesArray[] = (byte[]) connection.read();
                    FileOutputStream fos;
                    try {
                        fos = new FileOutputStream(userName+fileName);
                        fos.write(bytesArray);
                        fos.close();
                        System.err.println(fileName+" file download is complete!");
                    } catch (FileNotFoundException ex) {
                        //Logger.getLogger(ServerReaderWriter.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                       //Logger.getLogger(ServerReaderWriter.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                }
                else 
                {
                    connection.write(text+",I don't want to receive file") ;
                    connection.write(data);
                }
            }
            else
            {
                System.err.println("Invalid keyword!");
            }
            
        }
        //System.out.println("clientreader stops..........");
        
    }
    
}
