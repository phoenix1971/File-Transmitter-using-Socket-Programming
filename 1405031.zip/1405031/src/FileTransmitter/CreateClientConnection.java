/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileTransmitter;

import java.util.HashMap;

/**
 *
 * @author uesr
 */
public class CreateClientConnection implements Runnable{
    public HashMap<String,ClientInfo> clientList;
    public ConnectionUtillities connection;

    public CreateClientConnection(HashMap<String,ClientInfo> list, ConnectionUtillities con){
        clientList=list;
        connection=con;
    }
    
    @Override
    public void run() {
        try
        {
            Object o=connection.read();
            String username=o.toString();     
            //System.out.println("new username is "+ username );
            boolean flag = true ;
            if(clientList.containsKey(username))
            {
                System.out.println("Student "+username+"'s login is denied by server");
                flag = false ;
            }
            else 
            {
                clientList.put(username, new ClientInfo(connection, username) );
            }


            new Thread(new ServerReaderWriter(username,connection, clientList, flag )).start();
        }
        catch( Exception e)
        {
            //System.out.println("abar jhamela");
        }
    }

    
    
    
}
