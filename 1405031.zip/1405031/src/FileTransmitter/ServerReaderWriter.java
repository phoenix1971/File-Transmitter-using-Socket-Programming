/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileTransmitter;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author uesr
 */
public class ServerReaderWriter implements Runnable{

    public HashMap<String,ClientInfo> clientList;
    public ConnectionUtillities connection;
    public String user;
    public boolean flag ;
    public ServerReaderWriter(String username,ConnectionUtillities con, HashMap<String,ClientInfo> list, boolean Flag ){
        connection=con;
        clientList=list;
        user=username;
        flag = Flag ;
    }
    
    @Override
    public void run() {
        int errorFileID = -1 ;
        try
        {
            if(flag==false)
            {
                connection.write("login Failed");
                return  ;
            }
            else
            {
                connection.write("login done!");
                System.out.println("student "+user+ " is online now!!");
            }
            while(true){

                Object o=connection.read();
                String data=o.toString();
                //System.out.println("user "+ user + " & "+ data ) ;
                if(data.matches("yes,I want to receive file"))
                {
                    //System.out.println("client response 1 : " + data);
                    
                    o=connection.read();
                    data=o.toString(); 
                    //System.out.println("client response 2 : " + data);
                    String msg[] = data.split(":",4);
                    int fileID = Integer.parseInt(msg[3]);
                    errorFileID = fileID ;
                    int fileSize = Integer.parseInt(msg[2]) ;
                    byte [] bytesArray = new byte[fileSize] ; 
                    int chunksSize = Server.chunks.size() ;
                    //System.out.println("chuksSize = " + chunksSize);
                    int last = 0 ;
                    for(int i = 0; i < chunksSize ; i++)
                    {
                        Chunk chunk = (Chunk) Server.chunks.get(i) ;
                        if(chunk.fileID==fileID)
                        {
                            int chunkSize = chunk.bytesArray.length ;
                            for(int j = 0 ; j < chunkSize ; j++)
                            {
                                bytesArray[last+j] = chunk.bytesArray[j] ;
                            }
                            last += chunkSize ;
                        }

                    }
                    connection.write(bytesArray);
                    Server.removeChunks(fileID) ;
                    //Server.curSize -= fileSize ;
                    continue ;
                }
                else if(data.matches("no,I don't want to receive file"))
                {
                    o=connection.read();
                    data=o.toString(); 
                    String msg[] = data.split(":",4);
                    int fileID = Integer.parseInt(msg[3]);
                    int fileSize = Integer.parseInt(msg[2]) ;
                    //Server.curSize -= fileSize ;
                    Server.removeChunks(fileID);              
                    continue ;
                }

                if(data.matches("logout"))
                {
                    connection.write(data);
                    clientList.remove(user) ;
                    System.out.println("student "+user+" goes to offline now!");
                    return ;
                }
                String msg[]=data.split(":",2);

                String key   = msg[0];
                String value = msg[1];
                String studentID = value ;
                if(key.matches("studentID"))
                {
                    String username = value ;
                    studentID = value ;
                    //System.out.println("studentid is "+ studentID);

                    if( clientList.containsKey(username))
                    {
                        connection.write("receiver Found! plz send filename and filesize");
                    }
                    else 
                    {
                        connection.write("receiver not Found");
                        continue ;
                    }
                    data = (String) connection.read() ;
                    msg = data.split(":",2);
                    key = msg[0] ;
                    value = msg[1] ;
                    if(key.matches("fileName&Size"))
                    {
                        msg = value.split(":",2);
                        String fileName = msg[0] ;
                        int fileSize =  Integer.parseInt(msg[1]) ;
                        //System.out.println("filename = "+ fileName + " & fileSize "+ fileSize ) ;
                        byte[] bytesArray = new byte[fileSize] ;
                        int last = 0;
                        if(fileSize+Server.curSize>Server.maxSize)
                        {
                            connection.write("Sorry. due to overflow, file transmission can not be allowed");
                        }
                        else
                        {
                            //Server.curSize += fileSize ;
                            Random rand = new Random() ;
                            int maxChunkSize = rand.nextInt(1000)+100;
                            int fileID = Server.curFileID ;
                            errorFileID = fileID ;
                            Server.curFileID++ ;
                            //System.out.println("maxChunkSIze is "+ maxChunkSize);
                            connection.write(maxChunkSize);
                            connection.write(fileID);
                            int cnt = 0 ;
                            while(true)
                            {
                                String ms = (String) connection.read();
                                if(ms.matches("complete"))
                                {
                                    break ;
                                }
                                else if( ms.matches("TIMEOUT"))
                                {
                                    last = -1 ;
                                    break ;
                                }
                                Chunk chunk = (Chunk) connection.read() ;
                                Server.chunks.add(chunk);
                                Server.curSize += chunk.bytesArray.length ;
                                cnt++ ;
                                int chunkSize = chunk.bytesArray.length;
                                last += chunkSize ;
                                connection.write("got");
                            }
                            //System.out.println("cnt = "+ cnt ) ;
                            if( last == fileSize )
                            {
                                connection.write("file transmission successfully completed");
                                errorFileID = -1 ;
                            }
                            else 
                            {
                                data = "" ;
                                if(last==-1)data = " due to TIME-OUT" ;
                                
                                
                                connection.write("sorry. file transmission is failed"+data);
                                Server.removeChunks(fileID);
                                continue ;
                            }

                            //System.out.println("full file paoa ses");

                            //System.out.print("bytesarrays is "+ Arrays.toString(bytesArray));

        //                    FileOutputStream fos;
        //                    try {
        //                        fos = new FileOutputStream("server"+fileName);
        //                        fos.write(bytesArray);
        //                        fos.close();
        //                    } catch (FileNotFoundException ex) {
        //                        //Logger.getLogger(ServerReaderWriter.class.getName()).log(Level.SEVERE, null, ex);
        //                    } catch (IOException ex) {
        //                        //Logger.getLogger(ServerReaderWriter.class.getName()).log(Level.SEVERE, null, ex);
        //                    }
                            //System.out.println("studentID is "+ studentID );
                            if(clientList.containsKey(studentID))
                            {
                                ClientInfo clientInfo = clientList.get(studentID) ;
                                //System.out.println("info ->> "+ info.username);
                                clientInfo.connection.write(user+":"+fileName+":"+fileSize+":"+fileID);
                                //System.out.println("info -> "+info.username);
                                //o = info.connection.read() ;
                                //data = o.toString();
                                //System.out.println("client response " + data);

                            }
                            else 
                            {
                                Server.removeChunks(fileID) ;
                            }


                            //System.out.println("chunk is :  ");
                            //chunk.print();
                            //System.out.println("chunk fileid is "+chunk.fileID);

                        }   

                    }
                }
    //            if(clientList.containsKey(username)){
    //                ClientInfo info=clientList.get(username);
    //                info.connection.write(user+" - "+msgInfo);
    //            }
    //            else{
    //               connection.write(username+" not found ");
    //            }

            }
        }
        catch( Exception e)
        {
            System.out.println("student "+user+" goes to offline now!");
            clientList.remove(user) ;
            Server.removeChunks(errorFileID);
        }
    }
    
    
}
